<?php 
$pageStyle = 'catalogue';
include 'includes/header.php'; 
?>

<main>
    <section class="product-grid">
        <!-- Le reste du contenu de votre page catalogue -->
    </section>
</main>

<?php include 'includes/footer.php'; ?> 