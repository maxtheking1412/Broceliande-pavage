<?php 
$pageStyle = 'presentation';
include 'includes/header.php'; 
?>

<main>
    <section class="intro">
        <h2>Présentation de l'entreprise</h2>
        <!-- Le reste du contenu de votre page présentation -->
    </section>
</main>

<?php include 'includes/footer.php'; ?> 