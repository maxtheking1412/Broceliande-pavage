<?php 
$pageStyle = 'partenaire';
include 'includes/header.php'; 
?>

<main>
    <section class="partners-intro">
        <h2>Nos Partenaires</h2>
        <!-- Le reste du contenu de votre page partenaire -->
    </section>
</main>

<?php include 'includes/footer.php'; ?> 