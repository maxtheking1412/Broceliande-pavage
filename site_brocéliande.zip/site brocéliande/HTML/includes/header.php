<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brocéliande Pavage</title>
    <link rel="stylesheet" href="../CSS/common.css">
    <link rel="stylesheet" href="../CSS/animations.css">
    <?php if (isset($pageStyle)) : ?>
        <link rel="stylesheet" href="../CSS/<?php echo $pageStyle; ?>.css">
    <?php endif; ?>
</head>
<body>
    <div class="background-image"></div>
    <header class="header">
        <h1>Brocéliande Pavage</h1>
        <?php include 'nav.php'; ?>
    </header>
</body>
</html> 