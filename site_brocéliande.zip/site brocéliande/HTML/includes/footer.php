<footer>
        <p>&copy; <?php echo date('Y'); ?> Brocéliande Pavage. Tous droits réservés.</p>
    </footer>
    <script src="../js/scripts.js"></script>
</body>
</html> 