<nav class="nav-buttons">
    <a href="catalogue.php" class="nav-button">Catalogue</a>
    <a href="presentation.php" class="nav-button">Présentation</a>
    <a href="partenaire.php" class="nav-button">Partenaire</a>
    <a href="../index.html" class="nav-button">Accueil</a>
    <a href="contact.php" class="nav-button">Contact</a>
</nav> 