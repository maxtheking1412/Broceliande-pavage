<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $nom = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Cryptage du mot de passe
    $date_creation = date("Y-m-d H:i:s");

    // Création de la ligne à enregistrer
    $nouvelle_ligne = "Date: $date_creation | Nom: $nom | Email: $email | Password: $password\n";

    // Création du dossier data s'il n'existe pas
    if (!file_exists("../data")) {
        mkdir("../data", 0777, true);
    }

    // Ouverture du fichier en mode append (ajout)
    $fichier = fopen("../data/users.txt", "a");

    // Écriture dans le fichier
    fwrite($fichier, $nouvelle_ligne);

    // Fermeture du fichier
    fclose($fichier);

    $success = true;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brocéliande Pavage</title>
    <link rel="stylesheet" href="../CSS/contact.css">
</head>
<body>
    <?php 
    $pageStyle = 'contact';
    include 'includes/header.php'; 
    ?>

    <main>
        <section class="contact-intro">
            <h2>Nous Contacter</h2>
            <p>Vous souhaitez en savoir plus sur nos services ou nous poser une question ? Remplissez le formulaire ci-dessous ou contactez-nous directement.</p>
        </section>

        <?php if (isset($success)): ?>
            <div class="success-message" style="background-color: #4CAF50; color: white; padding: 15px; margin: 20px auto; max-width: 600px; text-align: center; border-radius: 5px;">
                Message envoyé avec succès !
            </div>
        <?php endif; ?>

        <!-- Formulaire de contact -->
        <section class="contact-form-section">
            <h3>Formulaire de Contact</h3>
            <form method="POST" class="contact-form">
                <div class="form-group">
                    <label for="prenom" class="required">Prénom</label>
                    <input type="text" id="prenom" name="prenom" required>
                </div>
                <div class="form-group">
                    <label for="name" class="required">Nom</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="societe">Nom de la société</label>
                    <input type="text" id="societe" name="societe">
                </div>
                <div class="form-group">
                    <label for="email" class="required">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5"></textarea>
                </div>
                <button type="submit" class="submit-btn">Envoyer</button>
            </form>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 