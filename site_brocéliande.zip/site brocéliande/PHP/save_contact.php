<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $prenom = $_POST['prenom'];
    $nom = $_POST['name'];
    $societe = isset($_POST['societe']) ? $_POST['societe'] : '';
    $email = $_POST['email'];
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $date_contact = date("Y-m-d H:i:s");

    // Création de la ligne à enregistrer
    $nouvelle_ligne = "Date: $date_contact | Prénom: $prenom | Nom: $nom | Société: $societe | Email: $email | Message: $message\n";

    // Création du dossier data s'il n'existe pas
    if (!file_exists("../data")) {
        mkdir("../data", 0777, true);
    }

    // Ouverture du fichier en mode append (ajout)
    $fichier = fopen("../data/contacts.txt", "a");

    // Écriture dans le fichier
    fwrite($fichier, $nouvelle_ligne);

    // Fermeture du fichier
    fclose($fichier);

    echo "success";
}
?> 