<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $societe = isset($_POST['societe']) ? $_POST['societe'] : '';
    $email = $_POST['email'];
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $date_contact = date("Y-m-d H:i:s");

    // Création de la ligne à enregistrer
    $nouvelle_ligne = "Prénom: $prenom | Nom: $nom | Société: $societe | Email: $email | Message: $message | Date: $date_contact\n";

    // Ouverture du fichier en mode append (ajout)
    $fichier = fopen("contacts.txt", "a");

    // Écriture dans le fichier
    fwrite($fichier, $nouvelle_ligne);

    // Fermeture du fichier
    fclose($fichier);

    echo "Message envoyé avec succès !";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>Contactez-nous</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div>
            <label>Prénom :</label>
            <input type="text" name="prenom" required>
        </div>
        <div>
            <label>Nom :</label>
            <input type="text" name="nom" required>
        </div>
        <div>
            <label>Nom de la société :</label>
            <input type="text" name="societe">
        </div>
        <div>
            <label>Email :</label>
            <input type="email" name="email" required>
        </div>
        <div>
            <label>Message :</label>
            <textarea name="message" rows="5" cols="30"></textarea>
        </div>
        <div>
            <input type="submit" value="Envoyer">
        </div>
    </form>
</body>
</html> 