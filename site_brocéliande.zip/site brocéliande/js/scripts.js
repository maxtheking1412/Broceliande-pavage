// Fonction pour le diaporama
let currentIndex = 0;

function showSlide(index) {
    const slides = document.querySelectorAll('.carousel-images img');
    if (index >= slides.length) currentIndex = 0;
    if (index < 0) currentIndex = slides.length - 1;

    const offset = -currentIndex * 100;
    document.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`;
}

document.getElementById('next').addEventListener('click', function() {
    currentIndex++;
    showSlide(currentIndex);
});

document.getElementById('prev').addEventListener('click', function() {
    currentIndex--;
    showSlide(currentIndex);
});
