<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $nom = $_POST['nom'];
    $societe = isset($_POST['societe']) ? $_POST['societe'] : '';
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Cryptage du mot de passe
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $date_creation = date("Y-m-d H:i:s"); // Format : AAAA-MM-JJ HH:MM:SS

    // Création de la ligne à enregistrer
    $nouvelle_ligne = "Nom: $nom | Société: $societe | Email: $email | Password: $password | Message: $message | Date: $date_creation\n";

    // Ouverture du fichier en mode append (ajout)
    $fichier = fopen("utilisateurs.txt", "a");

    // Écriture dans le fichier
    fwrite($fichier, $nouvelle_ligne);

    // Fermeture du fichier
    fclose($fichier);

    echo "Inscription réussie !";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inscription</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>Inscription</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div>
            <label>Nom :</label>
            <input type="text" name="nom" required>
        </div>
        <div>
            <label>Société :</label>
            <input type="text" name="societe">
        </div>
        <div>
            <label>Email :</label>
            <input type="email" name="email" required>
        </div>
        <div>
            <label>Mot de passe :</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Message :</label>
            <textarea name="message"></textarea>
        </div>
        <div>
            <input type="submit" value="S'inscrire">
        </div>
    </form>
</body>
</html> 